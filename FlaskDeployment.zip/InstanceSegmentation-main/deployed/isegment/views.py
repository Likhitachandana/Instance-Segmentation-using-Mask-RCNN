from django.shortcuts import render, redirect
from PIL import Image
import torch
from .models import IsegementDB, IsegementResult
from .forms import IsegementForm
from .model import get_model, get_transform
from .model import draw_masks, overlay_mask_on_image
import base64
from io import BytesIO
from torchvision import transforms


def get_image_base64(image):
    with BytesIO() as buffer:
        image.save(buffer, format="PNG")
        return base64.b64encode(buffer.getvalue()).decode("utf-8")

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Create your views here.
def index(request):
    if request.method == 'POST':
        form = IsegementForm(request.POST, request.FILES)
        print(request.FILES['image'].name)
        filename = request.FILES['image'].name

        transform = get_transform()
        model = get_model()

        if form.is_valid():
            form.save()

            image = IsegementDB.objects.last()
            image = Image.open(image.image).convert("RGB")
            img = image

            image = transform(image)
            image = image.unsqueeze(0)
            image = image.to(device)
            image = list(image)

            with torch.no_grad():
                _, predictions = model(image)
                labels = predictions[0]['labels']
                m = torch.mean(labels.float())
                p = m*100
                pred_labels = {
                    'Car': f'{p:.3f}%',
                    'Sign Board': f'{100-p:.3f}%',
                }
                print(pred_labels)
                #label = max(pred_labels, key=pred_labels.get)

                masks = predictions[0]['masks']
                print(masks.shape)
                masks,_ = draw_masks(masks)

                overlay_np = overlay_mask_on_image(image[0], masks, alpha=0.5)

                img = transforms.Resize((128,128))(img)

                img_b64 = get_image_base64(img)
                overlay_b64 = get_image_base64(overlay_np)

                context = {
                    'image': img_b64,
                    'mask': overlay_b64,
                    'label': pred_labels,
                    'filename': filename
                }
                print(type(img), type(overlay_np))
                print(img.size, overlay_np.size)

            return render(request, 'isegment/result.html', context)
    else:
        form = IsegementForm()
    return render(request, 'isegment/upload.html', {'form': form})



def result(request):
    image = IsegementDB.objects.last()
    isegments = IsegementResult.objects.last()

    return render(request, 'isegment/result.html' , {'image':image, 'isegments':isegments})