from django.contrib import admin
from django.urls import path, include
import isegment.views as views

urlpatterns = [
    path('', views.index, name='index'),
    path('result/', views.result, name='result'),
]