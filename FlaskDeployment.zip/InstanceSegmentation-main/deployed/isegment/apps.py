from django.apps import AppConfig


class IsegmentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'isegment'
