import torch
import numpy as np
from tqdm import tqdm
from PIL import Image,ImageDraw
import matplotlib.pyplot as plt
from torchvision import datasets, transforms

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(device)

model_path = 'C://Users//likhi//Downloads//InstanceSegmentation-main//InstanceSegmentation-main//deployed//model/newmodel.pt'

def get_model():
    model = torch.jit.load(model_path, map_location=device)
    model.to(device)
    model.eval()
    return model

def get_transform():
    transform = transforms.Compose([
        transforms.Resize((128,128)),
        transforms.ToTensor()
    ])
    return transform

def get_image_from_tensor(tensor):
    # image = tensor.cpu().clone()
    # image = image.squeeze(0)
    image = transforms.ToPILImage()(tensor)
    return image

def get_mask_from_tensor(tensor):
    # mask = tensor.cpu().clone()
    # mask = mask.squeeze(0)
    mask = transforms.ToPILImage()(tensor)
    return mask


def draw_masks(masks):
    # Convert the masks to numpy arrays
    masks_np = [mask.squeeze(0).numpy() for mask in masks]

    # Create an empty numpy array with shape (height, width, 3)
    result_np = np.zeros((*masks_np[0].shape, 3), dtype=np.uint8)

    # Assign a different color to each mask
    colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255)] # Red, green, blue
    for i, mask_np in enumerate(masks_np):
        result_np[mask_np != 0] = colors[i % len(colors)]

    # Convert the numpy array to a PIL Image and return it
    return result_np,Image.fromarray(result_np)


def overlay_mask_on_image(image_tensor, mask_np, alpha=0.5):
    # Convert image tensor to numpy array and permute dimensions
    image_np = image_tensor.permute(1, 2, 0).numpy()

    # Normalize mask numpy array to be between 0 and 1
    mask_np = (mask_np - mask_np.min()) / (mask_np.max() - mask_np.min())

    # Create a new numpy array for the overlay image
    overlay_np = np.zeros_like(image_np)

    # Apply the mask to each color channel of the image
    for c in range(3):
        overlay_np[..., c] = (1 - alpha) * image_np[..., c] + alpha * mask_np[..., c]

    # Convert the overlay numpy array to a PIL Image
    overlay_img = Image.fromarray((overlay_np * 255).astype(np.uint8))

    # Convert the image tensor to a PIL Image
    image_img = Image.fromarray(image_np.astype(np.uint8))

    # Create a new PIL Image with the image and overlay merged
    merged_img = Image.alpha_composite(image_img.convert('RGBA'), overlay_img.convert('RGBA'))

    # Return the merged PIL Image
    return merged_img
