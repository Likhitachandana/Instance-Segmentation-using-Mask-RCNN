from django.forms import ModelForm
from .models import IsegementDB, IsegementResult

class IsegementForm(ModelForm):
    class Meta:
        model = IsegementDB
        fields = ['image']


class IsegementResultForm(ModelForm):
    class Meta:
        model = IsegementResult
        fields = ['mask', 'labels']